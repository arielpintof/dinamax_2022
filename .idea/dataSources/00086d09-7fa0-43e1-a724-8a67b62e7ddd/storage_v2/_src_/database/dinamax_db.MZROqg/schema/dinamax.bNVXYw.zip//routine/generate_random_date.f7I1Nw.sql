create function generate_random_date(starting_timeframe integer, ending_timeframe integer) returns date
    language plpgsql
as
$$
DECLARE
    starting_interval INTERVAL DEFAULT make_interval(years => starting_timeframe);
    ending_interval   INTERVAL DEFAULT make_interval(years => (ending_timeframe - starting_timeframe));
BEGIN
    RETURN now() + (random() * (now() - ending_interval - now())) - starting_interval;
END;
$$;

alter function generate_random_date(integer, integer) owner to dinamax_dev;

