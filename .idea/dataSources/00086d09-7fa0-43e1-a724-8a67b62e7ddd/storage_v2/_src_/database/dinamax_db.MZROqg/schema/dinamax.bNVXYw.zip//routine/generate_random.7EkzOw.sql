create procedure generate_random()
    language plpgsql
as
$$
DECLARE
    fecha_inicio DATE;
    fecha_termino DATE;
    ano_i INTEGER;
    mes_i INTEGER;
    dia_i INTEGER;
    ano_t INTEGER;
    mes_t INTEGER;
    dia_t INTEGER;
    diferencia_entre_fechas DATE;

BEGIN
    FOR i in 1..5
        LOOP
            fecha_inicio = generate_random_date(6, 12);
            ano_i = EXTRACT(YEAR from fecha_inicio);
            mes_i = EXTRACT(MONTH from fecha_inicio);
            dia_i = EXTRACT(DAY from fecha_inicio);
            fecha_termino = generate_random_date(1, 2);
            ano_t = EXTRACT(YEAR from fecha_termino);
            mes_t = EXTRACT(MONTH from fecha_termino);
            dia_t = EXTRACT(DAY from fecha_termino);

            INSERT INTO dinamax.obra VALUES (i, dia_i, mes_i, ano_i, dia_t,mes_t,ano_t, 2, i);
            FOR j in 1..1000
                LOOP
                    INSERT INTO dinamax.registro(obra_id, ingreso_egreso) VALUES (i, (floor(random()*(2000000-10000+1))+10000));
                END LOOP;
        END LOOP;
END;
$$;

alter procedure generate_random() owner to dinamax_dev;

